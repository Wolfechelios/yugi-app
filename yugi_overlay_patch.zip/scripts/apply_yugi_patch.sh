    #!/usr/bin/env bash
    set -euo pipefail
    ROOT="$(pwd)"
    echo "Applying overlay patch to $ROOT"

    # 1) Ensure tsconfig path alias
    if [ -f tsconfig.json ]; then
      node - <<'NODE'
      const fs = require('fs');
      const p = 'tsconfig.json';
      const ts = JSON.parse(fs.readFileSync(p, 'utf8'));
      ts.compilerOptions ||= {};
      ts.compilerOptions.baseUrl = '.';
      ts.compilerOptions.paths = ts.compilerOptions.paths || {};
      ts.compilerOptions.paths['@/*'] = ['src/*'];
      fs.writeFileSync(p, JSON.stringify(ts, null, 2));
      console.log('Updated tsconfig.json path alias: @/* -> src/*');
NODE
    fi

    # 2) Overlay files
    rsync -av --ignore-existing src/ ./src/ >/dev/null 2>&1 || true
    # Force overwrite critical files
    cp -f src/app/globals.css ./src/app/globals.css
    cp -f src/lib/db.ts ./src/lib/db.ts
    cp -f src/lib/fileUpload.ts ./src/lib/fileUpload.ts
    mkdir -p ./src/components/ui
    cp -f src/components/ui/*.tsx ./src/components/ui/

    # 3) Codemod imports
    git ls-files | grep -E '\.(ts|tsx|js|jsx|mdx)$' | while read -r f; do
      sed -i '' 's#@/src/lib/db#@/lib/db#g' "$f" || true
      sed -i '' 's#@//src/lib/db#@/lib/db#g' "$f" || true
      sed -i '' 's#@/lib/db.ts#@/lib/db#g' "$f" || true
      sed -i '' 's#@/src/lib/fileUpload#@/lib/fileUpload#g' "$f" || true
    done
    echo "Normalized bad import paths."

    # 4) Move root detect route if present
    if [ -f detect_cards_route.ts ]; then
      mkdir -p src/app/api/detect-cards
      git mv -f detect_cards_route.ts src/app/api/detect-cards/route.ts 2>/dev/null || mv -f detect_cards_route.ts src/app/api/detect-cards/route.ts
      # fix its import
      sed -i '' 's#@/src/lib/fileUpload#@/lib/fileUpload#g' src/app/api/detect-cards/route.ts || true
      echo "Moved detect_cards_route.ts into app/api/detect-cards/route.ts"
    fi

    # 5) Fix server.ts top-level 'files' option misuse (move into limits or drop)
    if [ -f server.ts ]; then
      node - <<'NODE'
      const fs = require('fs');
      const p = 'server.ts';
      let s = fs.readFileSync(p, 'utf8');
      // If we find limits: { ... }, ensure files: 10 lives inside
      s = s.replace(/(limits\s*:\s*\{[^}]*\})\s*,\s*\n?\s*files\s*:\s*\d+/s, (m, g1) => {
        return g1.replace(/\}$/, ', files: 10}');
      });
      // Remove any leftover top-level files: N in option objects to satisfy TS
      s = s.replace(/(\{[\s\S]{0,200}?)(files\s*:\s*\d+\s*,?)/g, (_m, pre, entry) => {
        return pre;
      });
      fs.writeFileSync(p, s);
      console.log('Patched server.ts upload options (moved top-level files into limits or removed stray).');
NODE
    fi

    # 6) Add alt="" to specific images to satisfy a11y lint
    for f in src/components/search/CardDetailModal.tsx src/components/search/CardTile.tsx src/components/search/SuggestionsBox.tsx; do
      if [ -f "$f" ]; then
        perl -0777 -pe 's#<img(?![^>]*\balt=)([^>]*?)>#<img alt=""\1>#g' -i "$f"
        echo "Ensured alt attribute in $f"
      fi
    done

    echo "Overlay patch applied."
