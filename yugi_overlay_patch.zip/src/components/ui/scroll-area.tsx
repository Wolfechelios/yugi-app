import * as React from "react";
export interface ScrollAreaProps extends React.HTMLAttributes<HTMLDivElement> { viewportClassName?: string; }
export const ScrollArea = ({ className = "", children, ...props }: ScrollAreaProps) => (
  <div className={"relative " + className} {...props}>
    <div className="max-h-80 overflow-auto">{children}</div>
  </div>
);
export default ScrollArea;
