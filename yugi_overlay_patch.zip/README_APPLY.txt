Overlay Patch — Yugi Scan
=========================
This patch overlays missing/incorrect files and applies safe codemods that unblock your Next.js build.

Contains:
  - Tailwind v4 minimal globals.css
  - Supabase client (src/lib/db.ts) exporting {supabase, db, default}
  - fileUpload helper with flexible opts (string or { contentType, ext })
  - Minimal UI components for examples/websocket imports
  - apply_yugi_patch.sh to rewrite bad imports, move detect route, fix server.ts limits, add alt=""

How to apply
------------
1) Unzip the overlay into your project root (where package.json lives).
2) Run:
     chmod +x scripts/apply_yugi_patch.sh
     bash scripts/apply_yugi_patch.sh
3) Rebuild:
     rm -rf .next
     npm run build

Notes
-----
- Ensure env vars are set: NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY,
  optional NEXT_PUBLIC_SUPABASE_SCANS_BUCKET (defaults to 'scans').
- If you still don't need /examples/* at build time, you can move it out or exclude it in tsconfig.
